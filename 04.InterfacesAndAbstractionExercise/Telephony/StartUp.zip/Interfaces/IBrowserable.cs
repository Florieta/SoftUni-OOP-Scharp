﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony
{
    public interface IBrowserable
    {
        public string Browse(string url);
    }
}
